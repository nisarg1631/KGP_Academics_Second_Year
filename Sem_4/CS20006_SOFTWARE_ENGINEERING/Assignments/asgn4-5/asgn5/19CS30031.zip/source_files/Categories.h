// Nisarg Upadhyaya
// 19CS30031

#ifndef _CATEGORIES_H
#define _CATEGORIES_H

// namespace defining structs for use as tag-types in Booking and BookingCategory
namespace Categories{
    struct GeneralType{};
    struct LadiesType{};
    struct SeniorCitizenType{};
    struct DivyaangType{};
    struct TatkalType{};
    struct PremiumTatkalType{};
}

#endif